from flask import Flask, render_template, redirect, url_for, request, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_principal import Principal, Permission, RoleNeed, Identity, AnonymousIdentity, identity_changed

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Configuración de Flask-Login
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Configuración de Flask-Principal
principals = Principal(app)

# Definición de roles y permisos
admin_permission = Permission(RoleNeed('admin'))
editor_permission = Permission(RoleNeed('editor'))
user_permission = Permission(RoleNeed('user'))

# Modelo de usuario simple
class User(UserMixin):
    def __init__(self, id, username, password, role):
        self.id = id
        self.username = username
        self.password = password
        self.role = role

# Base de datos simulada
users = {
    1: User(1, 'admin', 'admin123', 'admin'),
    2: User(2, 'editor', 'editor123', 'editor'),
    3: User(3, 'user', 'user123', 'user')
}

@login_manager.user_loader
def load_user(user_id):
    return users.get(int(user_id))

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = next((u for u in users.values() if u.username == username and u.password == password), None)
        
        if user:
            login_user(user)
            
            # Configurar identidad para Flask-Principal
            identity = Identity(user.id)
            identity.provides.add(RoleNeed(user.role))
            identity_changed.send(app, identity=identity)
            
            flash('Has iniciado sesión correctamente.', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Usuario o contraseña incorrectos.', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    # Limpiar la identidad
    identity_changed.send(app, identity=AnonymousIdentity())
    logout_user()
    flash('Has cerrado sesión correctamente.', 'info')
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', user=current_user)

@app.route('/admin')
@admin_permission.require(http_exception=403)
@login_required
def admin_panel():
    return render_template('admin.html')

@app.route('/editor')
@editor_permission.require(http_exception=403)
@login_required
def editor_panel():
    return render_template('editor.html')

@app.route('/profile')
@user_permission.require(http_exception=403)
@login_required
def profile():
    return render_template('profile.html')

if __name__ == '__main__':
    app.run(debug=True)