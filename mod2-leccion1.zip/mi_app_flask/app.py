from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/productos')
def productos():
    lista_productos = [
        {'nombre': 'Ceramic Wax', 'precio': 60},
        {'nombre': 'car shampoo', 'precio': 20},
        {'nombre': 'Wax', 'precio': 25}
    ]
    return render_template('productos.html', productos=lista_productos)

@app.route('/usuarios')
def usuarios():
    lista_usuarios = ['Ana', 'Luis', 'Carlos', 'Marta']
    return render_template('usuarios.html', usuarios=lista_usuarios)

if __name__ == '__main__':
    app.run(debug=True)
