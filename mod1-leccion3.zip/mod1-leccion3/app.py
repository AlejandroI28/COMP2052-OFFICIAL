from flask import Flask, request, jsonify

app = Flask(__name__)

# Lista de usuarios
usuarios = []

# Ruta principal opcional para ver algo en "/"
@app.route('/')
def home():
    return "Servidor Flask activo. Prueba /info o /usuarios"

# Ruta GET para /info
@app.route('/info', methods=['GET'])
def info():
    system_info = {
        "sistema": "Windows",
        "version": "1.0",
        "arquitectura": "AMD64"
    }
    return jsonify(system_info)

# Ruta POST para crear un usuario
@app.route('/crear_usuario', methods=['POST'])
def crear_usuario():
    data = request.get_json()
    if 'nombre' not in data or 'correo' not in data:
        return jsonify({"error": "Nombre y correo son requeridos"}), 400
    usuarios.append(data)
    return jsonify({"mensaje": "Usuario creado exitosamente"}), 201

# Ruta GET para /usuarios
@app.route('/usuarios', methods=['GET'])
def obtener_usuarios():
    return jsonify(usuarios)

if __name__ == '__main__':
    app.run(debug=True)
