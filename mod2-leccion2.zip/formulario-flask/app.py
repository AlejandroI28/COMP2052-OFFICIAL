from flask import Flask, render_template, redirect, url_for, flash
from forms import FullQuoteForm
from flask_bootstrap import Bootstrap

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mi_clave_secreta'
Bootstrap(app)

@app.route('/', methods=['GET', 'POST'])
def cotizar():
    form = FullQuoteForm()
    if form.validate_on_submit():
        flash('Formulario enviado exitosamente.', 'success')
        return redirect(url_for('cotizar'))
    return render_template('cotizar.html', form=form)

if __name__ == '__main__':
    app.run(debug=True)
