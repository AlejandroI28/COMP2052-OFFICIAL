from flask import Flask, render_template, redirect, url_for, request
from flask_login import LoginManager, login_user, login_required, logout_user, UserMixin, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'tu_secreto_super_seguro'  # Cambia este secreto en producción

# Configuración de Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Modelo de usuario básico
class User(UserMixin):
    def __init__(self, id, username, password_hash, role):
        self.id = id
        self.username = username
        self.password_hash = password_hash
        self.role = role

# Diccionario simulado de usuarios
users = {
    "admin": User(id="1", username="admin", password_hash=generate_password_hash("admin123"), role="admin"),
    "user": User(id="2", username="user", password_hash=generate_password_hash("user123"), role="user")
}

# Cargar usuario
@login_manager.user_loader
def load_user(user_id):
    for user in users.values():
        if user.id == user_id:
            return user
    return None

# Rutas

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = users.get(username)
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            return 'Credenciales incorrectas', 401
    return render_template('login.html')

@app.route('/dashboard')
@login_required
def dashboard():
    return f"Bienvenido, {current_user.username}! Tu rol es {current_user.role}."

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

if __name__ == "__main__":
    app.run(debug=True)
